function Header(){
    return(
        <>
            <h1>Login</h1>
            <input placeholder="Enter UserName"></input>
            <br />
            <input placeholder="Enter Password"></input>
            <br />
            <button>Submit</button>
        </>
    )
}

export {Header};

