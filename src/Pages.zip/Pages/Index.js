function Index({name, age}) {

    let a = [1,2,3,4,5]
    return (
        <>
            <h6>Index Page {name} - {age}</h6>
            {
                a.map((res)=>{
                    return (
                        <h2>{res}</h2>
                    )
                })
            };
        </>
    )
}

export default Index;