import React, { useEffect, useMemo } from "react"

const Button = ({handleClick, name}) => {
    console.log(`${name} rendered`)
    return <button onClick={handleClick}>{name}</button>
}

export default React.memo(Button)