import logo from './logo.svg';
import './App.css';
import Login from './Pages/Login';
// import Home from './Pages/Home';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import Index from './Pages/Index';
import { createContext, useContext } from 'react';
import { AppContext } from './Pages/ContextApi';
import Home from './Home/Home';

function PrivateRoute({children}){
  let data = localStorage.getItem('login')
  if (!data){
   return <Navigate to='/login' />
  } else{
    return children
  }
}


export const contextTest = createContext();
function App() {

  return (
    <div>
    <contextTest.Provider value={{sample:"test"}}>
<Home />
    </contextTest.Provider>
    </div>
  );
}
 
export default App;

{/* <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Home/>} />
          <Route path='/index' element={
            <PrivateRoute>
              <Index />
            </PrivateRoute>
          } />
          <Route path='/login' element={<Login />} />
        </Routes>
      </BrowserRouter>
    </div> */}