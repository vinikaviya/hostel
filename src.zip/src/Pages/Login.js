import { useContext } from "react";
import { AppContext } from "./ContextApi";

function Login(){

    const {setData} = useContext(AppContext);
    return(
        <>
            <h1>Login</h1>
            <input placeholder="Enter UserName"></input>
            <br />
            <input placeholder="Enter Password"></input>
            <br />
            <button onClick={() => localStorage.setItem('login', true)}>Click</button>
        </>
    )
}

export default Login;

