import { useContext, useEffect, useState } from "react"
import { Link } from "react-router-dom";
import { AppContext } from "./ContextApi";

const Home = () => {

    const {setData} = useContext(AppContext);

    const handleStore = () => {
        sessionStorage.setItem('login', true)
        localStorage.setItem('un', btoa("sdfsdf"))
        localStorage.setItem('pw', "ssdfsdf")
    }

    return(
        <>
            <Link to="/index"> Index </Link>
            <button onClick={handleStore}>Click</button>
        </>
    )
}

export default Home;